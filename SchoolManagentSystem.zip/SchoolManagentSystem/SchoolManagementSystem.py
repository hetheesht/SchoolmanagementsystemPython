import School
import Student
import Teacher
class SchoolManagementSystem:
    def __init__(self):
        self.school = School()

    def add_teacher(self):
        name = input("Enter teacher's name: ")
        subject = input("Enter teacher's subject: ")
        employee_id = int(input("Enter teacher's employee ID: "))
        teacher = Teacher(name, subject, employee_id)
        self.school.add_teacher(teacher)
        print("Teacher added successfully.")

    def add_student(self):
        name = input("Enter student's name: ")
        roll_number = int(input("Enter student's roll number: "))
        grade = input("Enter student's grade: ")
        teacher_name = input("Enter teacher's name (if any): ")
        student = Student(name, roll_number, grade, teacher_name)
        self.school.add_student(student)
        print("Student added successfully.")

    def assign_teacher(self):
        teacher_name = input("Enter teacher's name: ")
        student_roll_numbers = list(map(int, input("Enter student roll numbers (comma-separated): ").split(',')))
        self.school.assign_teacher(teacher_name, student_roll_numbers)
        print("Teacher assigned successfully.")

    def display_all_details(self):
        self.school.display_info()

    def run(self):
        while True:
            print("\n1. Add Teacher\n2. Add Student\n3. Assign a Teacher\n4. Display All Details\n5. Exit")
            choice = int(input("Enter your choice: "))
            if choice == 1:
                self.add_teacher()
            elif choice == 2:
                self.add_student()
            elif choice == 3:
                self.assign_teacher()
            elif choice == 4:
                self.display_all_details()
            elif choice == 5:
                break
            else:
                print("Invalid choice. Please try again.")

# Directly instantiate and run the SchoolManagementSystem class
SMS = SchoolManagementSystem()
SMS.run()