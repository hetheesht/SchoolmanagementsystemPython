class Member:
    def __init__(self, name):
        self._name = name 

    def displayDetails(self):
        raise NotImplementedError("Subclass must implement abstract method")