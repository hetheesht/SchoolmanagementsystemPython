import Member
class Teacher(Member):
    def __init__(self,emp_id,name,subject):
        self.emp_id=emp_id
        self.name=name
        self.subject=subject
    def displayDetails(self):
        print("Employee id: ",emp_id," Name: ",name," Subject: ",subject)
    