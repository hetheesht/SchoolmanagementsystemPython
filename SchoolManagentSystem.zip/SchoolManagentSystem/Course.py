class Course:
    def __init__(self,course_id,course_name,students_joined):
        self.course_id=self.course_id
        self.course_name=self.course_name
        self.students_joined=self.students_joined
    def displayDetails(self):
        print("Course Id: ",self.course_id," Course Name: ",self.course_name," Students joined the course:"self.students_joined)
    def add_student(self, student):
        self.students_joined.append(student)