import Member
class Student(Member):
    def __init__(self,roll_no, name, gender, age):
        self.roll_no=roll_no
        self.name=name
        self.gender=gender
        self.age=age
    def displayDetails(self):
        print("Name: ",self.name," Roll number: ",self.roll_no," Gender: ",self.gender," Age: ",self.age)
    def set_teacher(self,teacher_name):
        self.teacher_name=teacher_name
    
    