import Student
import Teacher
import Course
class School:
    def __init__(self):
        self.students=[]
        self.teachers=[]
        self.courses=[]
        self.teacher_to_students={}
    def add_student(self, student):
        self.students.append(student)

    def add_teacher(self, teacher):
        self.teachers.append(teacher)

    def add_course(self, course):
        self.courses.append(course)

    def assign_teacher(self, teacher_name, student_roll_numbers):
        teacher = None
        for t in self.__teachers:
            if t.get_name() == teacher_name:
                teacher = t
                break
        if not teacher:
            print("No teacher found with the name", teacher_name)
            return

        if teacher_name not in self.teacher_to_students:
            self.teacher_to_students[teacher_name] = []

        for roll_number in student_roll_numbers:
            student = None
            for s in self.__students:
                if s.get_roll_number() == roll_number:
                    student = s
                    break
            if student:
                student.set_teacher(teacher_name)
                self.__teacher_to_students[teacher_name].append(roll_number)
    def display_teacher_students(self, teacher_name):
        if teacher_name in self.__teacher_to_students:
            print("Students assigned to", teacher_name," ", self.__teacher_to_students[teacher_name])
        else:
            print("No students assigned to" , teacher_name)

    def display_info(self):
        print("Students:")
        for student in self.__students:
            student.display_info()
        print("\nTeachers:")
        for teacher in self.__teachers:
            teacher.display_info()
        print("\nCourses:")
        for course in self.__courses:
            course.display_info()

